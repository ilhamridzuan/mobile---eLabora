import 'package:elabora_app/pages/cek_hasil_page.dart';
import 'package:flutter/material.dart';
import '../pages/login_page.dart';

final Map<String, WidgetBuilder> appRoutes = {
  '/login': (context) => const LoginPage(),
  '/beranda': (context) => const LoginPage(),
  '/cek_hasil': (context) => const CekHasilPage(),
};